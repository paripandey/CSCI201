
function fetchAPIdata() {
    event.preventDefault();
    
    const ticker = document.querySelector("#ticker_search_bar_id").value.trim().toUpperCase();
    
    if (ticker.length == 0) {
		document.querySelector("small").innerHTML = "Please enter a valid ticker.";
	}
	
	else {
		const apiKey = "cnus6shr01qub9j00tqgcnus6shr01qub9j00tr0";
    
	    const url = new URL(`https://finnhub.io/api/v1/stock/profile2?symbol=${ticker}&token=${apiKey}`);
	    const url2 = new URL(`https://finnhub.io/api/v1/quote?symbol=${ticker}&token=${apiKey}`);
	    
	    fetch(url)
	        .then(response => {
	            if (!response.ok) {
	                throw new Error('Network response was not ok');
	            }
	            return response.json();  
	        })
	        .then(data => {
				
	            const displayElement = document.querySelector("#homepage_main");
	            displayElement.innerHTML = ''; 
	            
	            document.querySelector("#ticker").innerHTML = ticker;
	            document.querySelector("#companyName").innerHTML = data.name;
	            document.querySelector("#exchange").innerHTML = data.exchange;
	            document.querySelector("#summary").innerHTML = "Summary <hr>";
	            
	            
	            document.querySelector("#companyInformation").innerHTML = "Company Information";
	        	document.querySelector("#ipo").innerHTML = "<strong>IPO Date:</strong> " + data.ipo;
	        	document.querySelector("#marketCap").innerHTML = "<strong>Market Cap ($M):</strong> " + data.marketCapitalization;
	        	document.querySelector("#shareOutstanding").innerHTML = "<strong>Share Outstanding:</strong> " + data.shareOutstanding;
	        	document.querySelector("#website").innerHTML = "<strong>Website:</strong> " + data.weburl;
	        	document.querySelector("#phone").innerHTML = "<strong>Phone:</strong> " + data.phone;

	        	displayElement.appendChild(document.querySelector("#stock_data"));
	        	
	        	
	        	})
	        	
	        
	
			        
		        .catch(error => {
		            const displayElement = document.querySelector("#homepage_main");
		            displayElement.innerHTML = `<p>Error fetching data: ${error.message}</p>`;
		        });
		

	    fetch(url2)
	        .then(response => {
	            if (!response.ok) {
	                throw new Error('Network response was not ok 2');
	            }
	            return response.json();  
	        })
	        .then(data => {
				
				document.querySelector("#h").innerHTML = "High Price: " + data.h;
	    		document.querySelector("#l").innerHTML = "Low Price: " + data.l;
	    		document.querySelector("#o").innerHTML = "Open Price: " + data.o;
	    		document.querySelector("#c").innerHTML = "Close Price: " + data.pc + `<hr>`;
	        })
	        
	        
	        .catch(error => {
	            const displayElement = document.querySelector("#homepage_main");
	            displayElement.innerHTML = `<p>Error fetching data: ${error.message}</p>`;
	        });

			
		
		
		
		
	}
    
        
    
}

function fetchAPIdataLoggedIn() {
    event.preventDefault();
    

    const ticker = document.querySelector("#ticker_search_bar_id").value.trim().toUpperCase();
    
    if (ticker.length == 0) {
		document.querySelector("small").innerHTML = "Please enter a valid ticker.";
	}
	
	else {
		const apiKey = "cnus6shr01qub9j00tqgcnus6shr01qub9j00tr0";
	
	    
	    
	    const url = new URL(`https://finnhub.io/api/v1/stock/profile2?symbol=${ticker}&token=${apiKey}`);
	    const url2 = new URL(`https://finnhub.io/api/v1/quote?symbol=${ticker}&token=${apiKey}`);
	    
	    fetch(url)
	        .then(response => {
	            if (!response.ok) {
	                throw new Error('Network response was not ok');
	            }
	            return response.json();  
	        })
	        .then(data => {
				
	            const displayElement = document.querySelector("#homepage_main");
	            displayElement.innerHTML = ''; 
	            
	            document.querySelector("#ticker").innerHTML = ticker;
	            document.querySelector("#companyName").innerHTML = data.name;
	            document.querySelector("#exchange").innerHTML = data.exchange;
	            document.querySelector("#summary").innerHTML = "Summary <hr>";
	            
	            
	            document.querySelector("#companyInformation").innerHTML = "Company Information";
	        	document.querySelector("#ipo").innerHTML = "<strong>IPO Date:</strong> " + data.ipo;
	        	document.querySelector("#marketCap").innerHTML = "<strong>Market Cap ($M):</strong> " + data.marketCapitalization;
	        	document.querySelector("#shareOutstanding").innerHTML = "<strong>Share Outstanding:</strong> " + data.shareOutstanding;
	        	document.querySelector("#website").innerHTML = "<strong>Website:</strong> " + data.weburl;
	        	document.querySelector("#phone").innerHTML = "<strong>Phone:</strong> " + data.phone;
	        	

	        	
	        	displayElement.append(document.querySelector("#container"));
	        	
	        	})
	
			        
		        .catch(error => {
		            const displayElement = document.querySelector("#homepage_main");
		            displayElement.innerHTML = `<p>Error fetching data: ${error.message}</p>`;
		        });

	    fetch(url2)
	        .then(response => {
	            if (!response.ok) {
	                throw new Error('Network response was not ok 2');
	            }
	            return response.json();  
	        })
	        .then(data => {
				document.getElementById("price_parameters").style.fontWeight = "bold";
				document.querySelector("#d").innerHTML = data.l;
	    		
	    		if (data.d > 0) {
					document.getElementById("color_parameters").style.color = "green";
					document.querySelector("#dp").innerHTML = `<i class = \"fa fa-caret-up\"></i>${data.d.toFixed(2)}(${data.dp.toFixed(2)}%)`;
				}
				
				else if (data.d < 0) {
					document.querySelector("#dp").innerHTML = `<i class = \"fa fa-caret-down\"></i>${data.d.toFixed(2)}(${data.dp.toFixed(2)}%)`;
					document.getElementById("color_parameters").style.color = "red";
				}
				
	    		
	    		
	    		var buy_form = document.querySelector("#buyForm");
	    		buy_form.method = "post";
	    		
	    		var label = document.createElement("label");
	    		label.name = "quantityLabel";
	    		label.innerHTML = "Quantity:";
	    		
	    		var quantity = document.createElement("input");
	    		quantity.name = "quantity";
	    		quantity.id = "quantity";
	    		

	    		
	    		var button = document.createElement("input");
	    		
	    		button.id = "buy_button";
	    		button.value = "BUY";
	    		button.type = "submit";
	    		console.log(button);
	    		
	
	    		
	    		buy_form.appendChild(label);
	    		buy_form.appendChild(quantity);
	    		buy_form.appendChild(document.createElement("br"));
	    		buy_form.appendChild(button);
	    		
	    		
				document.querySelector("#currentTimestamp").innerHTML = parseTime();
				document.querySelector("#h").innerHTML = "<strong>High Price: " + data.h + "</strong>";
	    		document.querySelector("#l").innerHTML = "<strong>Low Price: " + data.l + "</strong>";
	    		document.querySelector("#o").innerHTML = "<strong>Open Price: " + data.o + "</strong>";
	    		document.querySelector("#c").innerHTML = "<strong>Close Price: " + data.pc + "</strong> <hr>";
	        })
	        
	        
	        .catch(error => {
	            const displayElement = document.querySelector("#homepage_main");
	            displayElement.innerHTML = `<p>Error fetching data: ${error.message}</p>`;
	        });

	}

}

function parseTime() {
	const date = new Date();
    let hours = date.getHours();
    let minutes = date.getMinutes();
    let seconds = date.getSeconds();
    const lastTimestamp = new Date();
    
    const inSeconds = hours * 60 * 60 + minutes * 60 + seconds;

    const startSeconds = 6 * 60 * 60 + 30 * 60;  // 6:30 AM
    const endSeconds = 13 * 60 * 60;        // 1:00 PM

    if (inSeconds >= startSeconds && inSeconds <= endSeconds) {
		document.querySelector("#marketStatus").innerHTML = "Market is Open";
		localStorage.setItem("marketStatus", 1);
    }
    
    else {
		document.querySelector("#marketStatus").innerHTML = "Market is Closed";
		localStorage.setItem("marketStatus", 0);
		
		if (inSeconds < startSeconds) {
	        lastTimestamp.setDate(date.getDate() - 1);
	    }
	    
	    lastTimestamp.setHours(13, 0, 0); 
	
    }
    
    
    
    
    const currentYear = date.getFullYear();
    
	let currentDate = date.getDate();
	if (currentDate < 10) {
		currentDate = '0' + currentDate.toString();
	}

	let currentMonth = date.getMonth() + 1;
	if (currentMonth < 10) {
		currentMonth = '0' + currentMonth.toString();
	}
	
	if (hours < 10) {
		hours = '0' + hours.toString();
	}
	
	if (minutes < 10) {
		minutes = '0' + minutes.toString();
	}
	
	if (seconds < 10) {
		seconds = '0' + seconds.toString();
	}
	
	const currentYear1 = lastTimestamp.getFullYear();
    
	let currentDate1 = lastTimestamp.getDate();
	if (currentDate1 < 10) {
		currentDate1 = '0' + lastTimestamp.toString();
	}

	let currentMonth1 = date.getMonth() + 1;
	if (currentMonth1 < 10) {
		currentMonth1 = '0' + currentMonth1.toString();
	}
	

	
	if (localStorage.getItem("marketStatus") == 0) {
		document.querySelector("#marketStatus").innerHTML += ` (as of ${currentMonth1}-${currentDate1}-${currentYear1} 13:00:00)`;
	}


	const formatDate = `${currentMonth}-${currentDate}-${currentYear} ${hours}:${minutes}:${seconds}`;
	
	return formatDate;
			
}

function buyStock(){
	
	event.preventDefault();
	
	if (localStorage.getItem("marketStatus") == 1) {
		const ticker = document.querySelector("#ticker").innerHTML;
		let numStock = document.querySelector("#quantity").value;
		const price = Number.parseFloat(document.querySelector("#d").innerHTML);
		const userID = parseInt(localStorage.getItem("userID"));
		console.log(numStock);
		
		
		
		if (numStock.length == 0 || parseInt(numStock) < 1) {
			alert("Please enter a valid quantity.");
		}
		
		else {
		numStock = parseInt(numStock);
		
		const trade = {
			ticker: ticker,
			numStock: parseInt(numStock),
			price: price,
			userID: userID
		};
		
		
		fetch('TradeServlet', {
					
				method: "POST",
				headers: {"Content-Type": "application/json"},
				body: JSON.stringify(trade)	
			})
		
			.then(response => {
	            if (!response.ok) {
	                throw new Error('Network response tradeServlet was not ok 2');
	            }
	            return response.json();  
	        })
	        .then(data => {
				
				if (data == 0) {
					alert("FAILED: Purchase not possible")
				}
				
				else {
					alert("Bought " + numStock + " shares of " + ticker + " for $" + (numStock * price).toFixed(2));
						
				}
				
			})
			}
	}
	
	else {
		
		alert("Sorry, the market is closed right now.");
	}
	


	
}


function logout() {
	
	localStorage.setItem("userID", -1);
	window.location.href = "index.html";
}


function indexPage() {
	console.log(parseInt(localStorage.getItem("userID")));
	if (parseInt(localStorage.getItem("userID")) != -1) {
		
		let body = document.querySelector("body");
		body.innerHTML = ("        <div id=\"navbar\">\n"
						+ "            <div class=\"navbar_left_item\">\n"
						+ "                <div class=\"navbar_item\">\n"
						+ "                    JoesStocks\n"
						+ "                </div>\n"
						+ "            </div>\n"
						+ "            <div class=\"navbar_right_item\">\n"
						+ "                <div class=\"navbar_item\">\n"
						+ "                    <a href=\"index.html\" onclick = \"indexPage();\" class=\"navbar_link\">Home / Search</a>\n"
						+ "                </div>\n"
						+ "                <div class=\"navbar_item\">\n"
						+ "                    <a href = \"portfolio.html\" class=\"navbar_link\">Portfolio</a>\n"
						+ "                </div>\n"
						+ "                <div class = \"navbar_item\">\n"
						+ "                    <a class = \"navbar_link\" onclick = \"logout()\"; \">Logout</a>\n"
						+ "                </div>\n"
						+ "            </div>\n"
						+ "        </div>\n"
						+ "        <div id=\"homepage_main\">\n"
						+ "        	<div id=\"search_form_div\">\n"
						+ "        	    <h1 id=\"search_stocks_heading\">SEARCH STOCKS</h1>\n"
						+ "	            <form id=\"ticker_search_form\" name=\"ticker_search_form\" onsubmit=\"fetchAPIdataLoggedIn();\">\n"
						+ "	                <input id=\"ticker_search_bar_id\" type=\"text\" name=\"ticker_search_bar\" placeholder=\"Search by ticker...\">\n"
						+ "	                <button type = \"submit\" id=\"ticker_search_btn\">\n"
						+ "	                    <img id=\"search_icon\" src=\"search_icon.png\">\n"
						+ "	                </button>\n"
						+ "	            </form>\n"
						+ "             <small></small>\n"
						+ "        	</div>\n"
						+ "        </div>\n"
						+ "        <div id=\"container\">\n"
						+ "             <div id = \"main_into_2\">\n"
						+ "             <div id = \"company_parameters\">\n"
						+ "	            <h3 id = \"ticker\"></h3>\n"
						+ "	            <h4 id = \"companyName\"></h4>\n"
						+ "	            <p id = \"exchange\"></p>\n"
						+ "	            <form id = \"buyForm\" onsubmit = \"buyStock();\"></form>\n"
						+ "             </div>\n"
						+ "             <div id = \"color_parameters\">\n"
						+ "	            <h2 id = \"d\"></h2>\n"
						+ "	            <h2 id = \"dp\"></h2>\n"
						+ "	            <p id = \"currentTimestamp\"></p>\n"
						+ "             </div>\n"
						+ "             </div>\n"
						+ "             <br><br><br>\n"
						+ "             <div id = \"rest_of_info\">\n"
						+ "	            <p id = \"marketStatus\"></p>\n"
						+ "	            <p id = \"summary\"></p>\n"
						+ "             <div id = \"price_parameters\">"
						+ "	            <p id = \"h\"></p>\n"
						+ "	            <p id = \"l\"></p>\n"
						+ "	            <p id = \"o\"></p>\n"
						+ "	            <p id = \"c\"></p>\n"
						+ "	            <h3 id = \"companyInformation\"></h3>\n"
						+ "             </div>"
						+ "             <div id = \"companyInfoDiv\">"
						+ "	            <p id = \"ipo\" class = \"companyInfo\"></p>\n"
						+ "	            <p id = \"marketCap\" class = \"companyInfo\"></p>\n"
						+ "	            <p id = \"shareOutstanding\" class = \"companyInfo\"></p>\n"
						+ "	            <p id = \"website\" class = \"companyInfo\"></p>\n"
						+ "	            <p id = \"phone\" class = \"companyInfo\"></p>\n"
						+ "             </div>\n"
						+ "             </div>\n"
						+ "      	</div>\n");
		
	}

}


