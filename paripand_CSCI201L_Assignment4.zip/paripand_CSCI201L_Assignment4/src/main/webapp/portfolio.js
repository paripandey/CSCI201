function tradeFromPortfolio(i) {

	
	const date = new Date();
    let hours = date.getHours();
    let minutes = date.getMinutes();
    let seconds = date.getSeconds();
    const lastTimestamp = new Date();
    
    

    const inSeconds = hours * 60 * 60 + minutes * 60 + seconds;

    const startSeconds = 6 * 60 * 60 + 30 * 60;  // 6:30 AM
    const endSeconds = 13 * 60 * 60;        // 1:00 PM


    if (inSeconds >= startSeconds && inSeconds <= endSeconds) {
		localStorage.setItem("marketStatus", 1);
    }
    
    else {
		localStorage.setItem("marketStatus", 0);
    }
    
    

	
	if (localStorage.getItem("marketStatus") == 1) {
		let option = 0;
		const table_node = document.getElementsByClassName("tradeTable").item(i);
		const ticker_node = table_node.firstChild;
		const index = table_node.firstChild.innerHTML.indexOf(" ");
		const ticker = table_node.firstChild.innerHTML.substring(4, index);
		console.log(ticker);
		const price = Number.parseFloat(table_node.childNodes[1].firstChild.childNodes[1].childNodes[1].innerHTML);
		const userID = parseInt(localStorage.getItem("userID"));
	
		let quantity = document.getElementsByClassName("quantity").item(i).value;

		const buy = document.getElementsByClassName("buy").item(i);
		const sell = document.getElementsByClassName("sell").item(i);
		
		
		if ((!buy.checked && !sell.checked) || quantity == null || parseInt(quantity) < 1) {
			alert("FAILED, transaction not possible (invalid quantity)");
		}
		
		else if (buy.checked) {
			option = 1;
		}
		
		else if (sell.checked) {
			option = 2;
			quantity *= -1;
		}
		
		
		if (option != 0) {
			quantity = parseInt(quantity);
			
			const trade = {
				
				ticker: ticker,
				price: price,
				numStock: quantity,
				userID: userID
			};
			
			console.log(trade);
			
			
			fetch('TradeServlet', {
					
				method: "POST",
				headers: {"Content-Type": "application/json"},
				body: JSON.stringify(trade)	
			})
		
			.then(response => {
	            if (!response.ok) {
	                throw new Error('Network response tradeServlet was not ok 2');
	            }
	            return response.json();  
	        })
	        .then(data => {
				
				console.log(data);
				if (data == 0) {
					alert("FAILED, transaction not possible");
				}
				
				else {
					
					if (option == 1) {
						alert("Bought " + quantity + " " + ticker + " stock(s)");
					}
					
					else {
						alert("Sold " + (quantity*-1) + " " + ticker + " stock(s)");
					}
					
					window.location.href = "portfolio.html";					
				}
				
			})
		}
	}
	
	else {
		
		alert("Sorry, the market is closed right now.");
	}
}



function loadPortfolio() {
	
	const userID = parseInt(localStorage.getItem("userID"));
	console.log(userID);
	
	const url = `PortfolioServlet?userID=${encodeURIComponent(userID)}&parameter=${encodeURIComponent(1)}`;
	let done = false;
	let tav_number = 0;
	
	fetch(url, {
				method: "GET",
				headers: {"Accept": "application/json"},
			})
		
		.then(response => {
            if (!response.ok) {
                throw new Error('Network response portfolioServlet was not ok 2');
            }
            

            return response.json();

        })
        .then(data => {

        	document.getElementById("cash_balance").innerHTML += data.toFixed(2);
        	document.getElementById("tav").innerHTML = data.toFixed(2);
        	tav_number = parseFloat(document.getElementById("tav").innerHTML);
        	done = true;
        	
	
				
			})
	
	
	const url2 = `PortfolioServlet?userID=${encodeURIComponent(userID)}&parameter=${encodeURIComponent(2)}`;
	let counter = 0;
	
	fetch(url2, {
				method: "GET",
				headers: {"Accept": "application/json"},
			})
		
		.then(response => {
            if (!response.ok) {
                throw new Error('Network response portfolioServlet was not ok 2');
            }
            

            return response.json();
        })
        .then(data => {
			const trades = data;
			if (data.length == 0) {
				//document.getElementById("tav_label").innerHTML += tav_number.toFixed(2); //TAV.toFixed(2);
				document.getElementById("tav_label").innerHTML += (50000).toFixed(2); //TAV.toFixed(2);
				alert("You have nothing in your portfolio!");
			}
			
			else {
				for (let i = 0; i < trades.length; i++) {
				const t = trades[i];
				let j = i;

				const table = document.createElement("table");
				table.classList = "tradeTable";
				const tr1 = document.createElement("tr");
				tr1.classList = "grayRow";
				const tr2 = document.createElement("tr");
				tr2.classList = "actual_data";
				const tr3 = document.createElement("tr");
				tr3.classList = "grayRow portfolioTrade";
				
								
				const innerTable = document.createElement("table");
				innerTable.classList = "innerTables";
				const itr1 = document.createElement("tr");
				const itd11 = document.createElement("td");
				itd11.innerHTML = "Quantity:  ";
				const itd12 = document.createElement("td");
				itd12.innerHTML = t.numStocks;
				if (t.numStocks > 0) {
					document.getElementById("portfolio_items").appendChild(table);
				}
				const itd13 = document.createElement("td");
				itd13.innerHTML = "Change:";
				const itd14 = document.createElement("td");
				itd14.className = "change";
				itr1.appendChild(itd11);
				itr1.appendChild(itd12);
				itr1.appendChild(itd13);
				itr1.appendChild(itd14);
				
				
				const itr2 = document.createElement("tr");
				const itd21 = document.createElement("td");
				itd21.innerHTML = "Avg. Cost / Share:";
				const itd22 = document.createElement("td");
				itd22.innerHTML = (t.totalCost/t.numStocks).toFixed(2);
				const itd23 = document.createElement("td");
				itd23.innerHTML = "Current Price:";		
				const itd24 = document.createElement("td");		
				itr2.appendChild(itd21);
				itr2.appendChild(itd22);
				itr2.appendChild(itd23);
				itr2.appendChild(itd24);
				
						
				const itr3 = document.createElement("tr");
				const itd31 = document.createElement("td");
				itd31.innerHTML = "Total Cost:";
				const itd32 = document.createElement("td");
				itd32.innerHTML = Number.parseFloat(t.totalCost).toFixed(2);
				const itd33 = document.createElement("td");
				itd33.innerHTML = "Market Value:";
				const itd34 = document.createElement("td");
				itd34.classList = "market_value";
				itr3.appendChild(itd31);
				itr3.appendChild(itd32);
				itr3.appendChild(itd33);
				itr3.appendChild(itd34);
				
				innerTable.appendChild(itr1);
				innerTable.appendChild(itr2);
				innerTable.appendChild(itr3);
				
				tr2.appendChild(innerTable);
				
				tr3.innerHTML =
				
				
				"<form method=\"post\">"

			        +"<div class=\"form-group\">"
			          +"<label for=\"quantity\">Quantity:</label>"
			            +"<input type=\"input\" class=\"quantity\" name=\"quantity\">"
			        +"</div>"
			
			
			        +"<div class=\"form-group\">"
			            +"<label class=\"action-inputs\">"
			                +"<input type=\"radio\" class=\"buy\" name=\"action\" value=1>Buy</label>"
			            +"<label class=\"action-inputs\">"
			            +"<input type=\"radio\" class=\"sell\" name=\"action\" value=2>Sell</label></div>"
			
			        +`<input class = \"submit_button\" type=\"submit\" onclick = \"tradeFromPortfolio(${i});\"></form>`
			        
		     	table.appendChild(tr1);
				table.appendChild(tr2);
				table.appendChild(tr3);
				
	
			        
			    const apiKey = "cnus6shr01qub9j00tqgcnus6shr01qub9j00tr0";
				let url3 = new URL(`https://finnhub.io/api/v1/stock/profile2?symbol=${t.ticker}&token=${apiKey}`);
				
			    fetch(url3)
			        .then(response => {
			            if (!response.ok) {
			                throw new Error('Network response was not ok 2');
			            }
			            return response.json(); 
			        })
			        .then(data => {
						tr1.innerHTML = `<h3>${t.ticker} - ${data.name}</h3>`;

					
			        })
			        
			        
			        .catch(error => {
			            console.log(error);
			        });
	    		
			    let url4 = new URL(`https://finnhub.io/api/v1/quote?symbol=${t.ticker}&token=${apiKey}`);
			    
				
				fetch(url4)
			        .then(response => {
			            if (!response.ok) {
			                throw new Error('Network response was not ok 2');
			            }
			            return response.json();  
			        })
			        .then(data => {
						if (data.d > 0) {
							
							itd14.style.color = "green";
							itd14.innerHTML = `<i class = \"fa fa-caret-up\"></i>${data.d.toFixed(2)}`;

						}
						
						else if (data.d < 0) {
							
							itd14.style.color = "red";
							itd14.innerHTML = `<i class = \"fa fa-caret-down\"></i>${data.d.toFixed(2)}`;
						}
						
						itd24.innerHTML = data.c.toFixed(2);
						tav_number += parseFloat(itd24.innerHTML);
						itd34.innerHTML = (data.c * t.numStocks).toFixed(2);
						counter++;

						

						
						if (counter == trades.length && done) {
							
							let TAV = parseFloat(document.getElementById("tav").innerHTML);
							console.log(tav_number);
							
							const all_market_values = document.getElementsByClassName("market_value");
							for (let i = 0; i < all_market_values.length; i++) {
								TAV += parseFloat(all_market_values.item(i).innerHTML);
							}
							console.log(TAV);
							document.getElementById("tav_label").innerHTML += tav_number.toFixed(2); //TAV.toFixed(2);
						}

			        })
			        
			        .catch(error => {
			            console.log(error);
			        });				
			}
				
				
				
			}
			
			
			

			
		})
		
}




function logout() {
	
	localStorage.setItem("userID", -1);
	window.location.href = "index.html";
}