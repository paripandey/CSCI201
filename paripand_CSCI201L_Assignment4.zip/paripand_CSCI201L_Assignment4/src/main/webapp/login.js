function login() {
	event.preventDefault();
	
	const username = document.querySelector("#username_l").value;
	const password = document.querySelector("#password_l").value;
	

	
	const user = {
		username: username,
		password: password
	};
	
	
	fetch('LoginServlet', {
				
			method: "POST",
			headers: {"Content-Type": "application/json"},
			body: JSON.stringify(user)	
		})
		
		.then(response => {
            if (!response.ok) {
                throw new Error('Network response tradeServlet was not ok 2');
            }
            
            
            return response.json();
        })
        .then(data => {
			console.log(data);
			
			
			if (data == -1) {
				document.getElementById("invalid_username1").innerHTML = "Username does not exist.";
				document.getElementById("invalid_login").innerHTML = "";
			}
			
			else if (data == -2) {
				document.getElementById("invalid_login").innerHTML = "Username or password is incorrect.";
				document.getElementById("invalid_username1").innerHTML = "";
			}
			
			else if (data == 0) {
				document.getElementById("invalid_login").innerHTML = "Missing login info.";
				document.getElementById("invalid_username1").innerHTML = "";			
			}
			
			else {
				document.getElementById("invalid_login").innerHTML = "";
				document.getElementById("invalid_username1").innerHTML = "";
				localStorage.setItem("userID", parseInt(data));
				window.location.href = "index.html";
			}
			
		})
		
}

function register() {
	event.preventDefault();
	
	const username = document.querySelector("#username_r").value;
	const password = document.querySelector("#password_r").value;
	const password2 = document.querySelector("#password_r2").value;
	const email = document.querySelector("#email").value;
	
	if (username.length > 0 && password.length > 0 && password2.length > 0 && email.length > 0 && password != password2) {
		document.getElementById("invalid_register").innerHTML = "The 2 passwords do not match.";
		document.getElementById("invalid_username").innerHTML = "";
		document.getElementById("invalid_email").innerHTML = "";
	}
	
	
	else {
	
		const user = {
			username: username,
			password: password,
			password2: password2,
			email: email
		};
		
	
		
		fetch('RegisterServlet', {
					
				method: "POST",
				headers: {"Content-Type": "application/json"},
				body: JSON.stringify(user)	
			})
			
			.then(response => {
	            if (!response.ok) {
	                throw new Error('Network response registerServlet was not ok 2');
	            }
	            
	            
	            return response.json();
	
	        })
	        .then(data => {
				if (data == -1) {
					document.getElementById("invalid_username").innerHTML = "Username already exists.";
					document.getElementById("invalid_register").innerHTML = "";
					document.getElementById("invalid_email").innerHTML = "";
				}
				
				else if (data == -2) {
					document.getElementById("invalid_email").innerHTML = "Email is already registered.";
					document.getElementById("invalid_username").innerHTML = "";
					document.getElementById("invalid_register").innerHTML = "";
				}
				
				
				else if (data == 0) {
					document.getElementById("invalid_register").innerHTML = "Missing registration info.";
					document.getElementById("invalid_username").innerHTML = "";	
					document.getElementById("invalid_email").innerHTML = "";		
				}
				
				else {
					const p = document.createElement("p");
					p.innerHTML = data;
					console.log(p);
					localStorage.setItem("userID", parseInt(p.innerHTML));
					console.log(localStorage.getItem("userID"));
					window.location.href = "index.html";
				}
				
			})
	}

}


function logout() {
	
	localStorage.setItem("userID", -1);
	window.location.href = "index.html";
}