package paripand_CSCI201L_Assignment4;

import java.io.IOException;
import java.io.PrintWriter;
/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;*/

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.google.gson.Gson;



@WebServlet("/RegisterServlet")

public class RegisterServlet extends HttpServlet {
	
	public static final long serialVersionUID = 1L;
	

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		
		Gson gson = new Gson();
		
		UserClass u = gson.fromJson(request.getReader(), UserClass.class);
		
		String username = u.getUsername();
		String password = u.getPassword();
		String email = u.getEmail();
		String password2 = u.getPassword2();
		
		
		/*PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		/*UserClass user = new Gson().fromJson(request.getReader(), UserClass.class);
		String username = user.getUsername();
		String password = user.getPassword();
		String email = user.getEmail();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");

		Gson gson = new Gson();*/
		
		
		if (username == null || username.isBlank() || password == null || password.isBlank() || password2 == null || password2.isBlank() || email == null || email.isBlank()) {
		
			pw.write(gson.toJson(0));
			pw.flush();
		}
		
		else {
			System.out.println("password: " + password);
			System.out.println("password2: " + password2);
			System.out.println("equals: " + (password == password2));
			
			int userID = JDBCConnector.registerUser(username, password, password2, email);
		
			if (userID == -1) {
				
				pw.write(gson.toJson(-1));
				pw.flush();
			}
			
			else if (userID == -2) {
				pw.write(gson.toJson(-2));
				pw.flush();
			}
			
			
			else {
				pw.write(gson.toJson(userID));
				pw.flush();
			}
			

		}
		
		
		
	}
}


