package paripand_CSCI201L_Assignment4;

public class PortfolioItem {
	
	private String ticker;
	private double totalCost;
	private int numStocks;
	private int userID;
	
	public PortfolioItem(String ticker, double totalCost, int numStocks, int userID) {
		
		this.ticker = ticker;
		this.totalCost = totalCost;
		this.numStocks = numStocks;
		this.userID = userID;
	}
	

	
	public double getTotalCost() {
		
		return totalCost;
		
	}
	

	public int getNumStocks() {
		
		return numStocks;
		
	}
	
	public String getTicker() {
		
		return ticker;
		
	}
	
	public int getUserID() {
		
		return userID;
	}

}
