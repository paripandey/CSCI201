package paripand_CSCI201L_Assignment4;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet ("/PortfolioServlet")

public class PortfolioServlet extends HttpServlet {
	
	public static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		
		Gson gson = new Gson();
		
		int userID = Integer.parseInt(request.getParameter("userID"));
		
		int parameter = Integer.parseInt(request.getParameter("parameter"));
		
		if (parameter == 1) {
			double balance = JDBCConnector.getBalance(userID);
			
			pw.write(gson.toJson(balance));
			pw.flush();
	
		}
		
		
		else if (parameter == 2) {
			ArrayList<PortfolioItem> trades = JDBCConnector.loadPortfolio(userID);
		
			pw.write(gson.toJson(trades));
			pw.flush();
	
		}
		
		
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		
		
		
		
		
		
	}
	

}
