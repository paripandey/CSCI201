package paripand_CSCI201L_Assignment4;

public class Trade {
	
	private String ticker;
	private int numStock;
	private double price;
	private int userID;
	
	public Trade(String ticker, int numStock, double price, int userID) {
		
		this.ticker = ticker;
		this.numStock = numStock;
		this.price = price;
		this.userID = userID;
	}
	
	
	public double getCost() {
		
		return price * numStock;
	}
	
	public double getPrice() {
		
		return price;
		
	}
	

	public int getNumStock() {
		
		return numStock;
		
	}
	
	public String getTicker() {
		
		return ticker;
		
	}
	
	public int getUserID() {
		
		return userID;
	}
	
	

}
