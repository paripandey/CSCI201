package paripand_CSCI201L_Assignment4;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;


@WebServlet("/LoginServlet")

public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		PrintWriter pw = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		
		Gson gson = new Gson();
		
		UserClass u = gson.fromJson(request.getReader(), UserClass.class);

	
		String username = u.getUsername();
		String password = u.getPassword();

		
		if (username == null || username.isBlank() || password == null || password.isBlank()) {
			
			//response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			String error = "Login info missing";
			pw.write(gson.toJson(0));
			pw.flush();
		
		}
		
		else {
			int userID = JDBCConnector.login(username, password);
		
			if (userID == -1) {
				//response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				String error = "Username does not exist.";
				pw.write(gson.toJson(-1));
				pw.flush();
			}
			
			else if (userID == -2) {
				//response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				String error = "Username or password is incorrect.";
				pw.write(gson.toJson(-2));
				pw.flush();
			}
	
			
			else {
				//response.setStatus(HttpServletResponse.SC_OK);
				pw.write(gson.toJson(userID));
				pw.flush();
			}
			
			
		}
		
		
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		
		pw.write("ite");*/
			
	}

}
