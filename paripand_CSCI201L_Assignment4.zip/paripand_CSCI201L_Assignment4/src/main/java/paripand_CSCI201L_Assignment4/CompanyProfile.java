package paripand_CSCI201L_Assignment4;

import java.net.http.HttpResponse;

public class CompanyProfile {
	
	private String ticker;
	private String companyName;
	private String exchange;
	private String IPODate;
	private double marketCap;
	private double shareOutstanding;
	private String website;
	private String phone;
	
	public CompanyProfile(HttpResponse one, HttpResponse two) {
		
		
		
		
		
		
		
		
	}
	

}
