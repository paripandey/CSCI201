package paripand_CSCI201L_Assignment4;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/TradeServlet")

public class TradeServlet extends HttpServlet {
	
	public static final long serialUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");

		
		Trade t = new Gson().fromJson(request.getReader(), Trade.class);
		
		Gson gson = new Gson();
		
		int result = JDBCConnector.buyStock(t);
		
		if (result == 0) {
			//response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			pw.write(gson.toJson(0));
			pw.flush();
		}
		
		else {
			//response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			//String error = "Bought " + numStocks + " shares of " + ticker + " for $" + cost;
			pw.write(gson.toJson(1));
			pw.flush();
		}
	}
	
	
	
	
	

}
