package paripand_CSCI201L_Assignment4;

import java.net.http.HttpResponse;

public class Stock {
	
	private double h;
	private double l;
	private double o;
	private double c;
	
	
	public Stock(HttpResponse one, HttpResponse two) {
		
		
		
		
		
		
		
		
	}
	

}
