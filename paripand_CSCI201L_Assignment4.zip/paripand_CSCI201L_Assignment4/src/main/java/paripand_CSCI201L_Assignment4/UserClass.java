package paripand_CSCI201L_Assignment4;

public class UserClass {
	
	
	private String username;
	private String password;
	private String password2;
	private String email;
	private double balance;
	
	public UserClass(String username, String password, String password2, String email, int balance) {
		
		this.username = username;
		this.password = password;
		this.password2 = password2;
		this.email = email;
		this.balance = balance;
	}
	
	public String getUsername() {
		
		return username;
	}

	public String getPassword()
	{
		
		return password;
	}
	
	public String getPassword2()
	{
		
		return password2;
	}
	
	public String getEmail() {
		
		return email;
	}
	
	public double getBalance() {
		
		return balance;
	}
	
	public boolean passwordsMatch() {
		
		return password == password2;
	}
	
}
