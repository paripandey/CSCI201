package paripand_CSCI201L_Assignment4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.lang.Double;

public class JDBCConnector {
	
	public static int registerUser(String username, String password, String password2, String email) {
			
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}
		
		catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		int userID = -1;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/assignment4?user=root& password=Banari69");
			st = conn.createStatement();
			System.out.println(username);
			rs = st.executeQuery("SELECT * FROM Users WHERE Username='" + username + "'");
			
			if (!rs.next()) {
				st = conn.createStatement();
				rs = st.executeQuery("SELECT * FROM Users WHERE Email='" + email + "'");
				if (!rs.next()) {
					rs.close();
					st.execute("INSERT INTO Users (Username, Password, Email, Balance) VALUES ('" + username + "', '" + password + "', '" + email + "', 50000)");
					rs = st.executeQuery("SELECT LAST_INSERT_ID()");
					rs.next();
					
					userID = rs.getInt(1);
				}
				
				else {
					userID = -2; 
				}
			}
		}
		
		catch (SQLException sqle) {
			System.out.println("SQLException is in registerUser");
			sqle.getMessage();
		}
		
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (st != null) {
					st.close();
				}
				
				if (conn != null) {
					conn.close();
				}
			}
			
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return userID;
	
	}

	
	
	public static int login(String username, String password) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}
		
		catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		int userID = -1;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/assignment4?user=root&password=Banari69");
			st = conn.createStatement();
			rs = st.executeQuery("SELECT UserID, Username, Password FROM Users WHERE Username='" + username + "'");
			
			if (rs.next()) {
				
				if (password.equals(rs.getString("Password"))) {
					//rs.close();
					/*rs = st.executeQuery("SELECT LAST_INSERT_ID();");
					rs.next();*/
					userID = rs.getInt("UserID");
					rs.close();
				}
				
				else {
					userID = -2;	
				}
				
			
			}
		}
		
		catch (SQLException sqle) {
			System.out.println("SQLException is in login");
			sqle.printStackTrace();
		}
		
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (st != null) {
					st.close();
				}
				
				if (conn != null) {
					conn.close();
				}
			}
			
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return userID;
	
	}
	
	public static int buyStock(Trade t) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}
		
		catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		int result = 0;
		int verify1 = 0;
		int verify2 = 0;
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/assignment4?user=root&password=Banari69");
			st = conn.createStatement();
			rs = st.executeQuery("SELECT Balance FROM Users WHERE UserID=" + t.getUserID() + "");
			
			if (rs.next()) {
				double balance = Double.parseDouble(rs.getString("Balance"));

				if (balance >= t.getCost()) {
					rs.close();
					verify1 = st.executeUpdate("UPDATE Users SET Balance = " + (balance - t.getCost()) + " WHERE UserID=" + t.getUserID() + "");
					verify2 = st.executeUpdate("INSERT INTO Portfolio (UserID, Ticker, NumStock, Price) VALUES(" + t.getUserID() + ", '" + t.getTicker() + "', " + t.getNumStock() + ", " + t.getPrice() +")");
					if ((verify1 == 1) && (verify2 == 1)) { 
						result = 1;
					}
					
				}
			
			}
		}
		
		catch (SQLException sqle) {
			System.out.println("SQLException is in buyStock");
			sqle.printStackTrace();
		}
		
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (st != null) {
					st.close();
				}
				
				if (conn != null) {
					conn.close();
				}
			}
			
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		return result;
		
	}
	
	
	public static ArrayList<PortfolioItem> loadPortfolio(int userID) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}
		
		catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		ArrayList<PortfolioItem> trades = new ArrayList<PortfolioItem>();
		
		
		
		/*int verify1 = 0;
		int verify2 = 0;*/
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/assignment4?user=root&password=Banari69");
			st = conn.createStatement();
			rs = st.executeQuery("SELECT Ticker, SUM(NumStock) AS NumStocks, SUM(NumStock * Price) AS TotalCost FROM Portfolio WHERE UserID="+userID+" GROUP BY Ticker;");
			
			while (rs.next()) {
				String ticker = rs.getString("Ticker");
				int numStocks = rs.getInt("NumStocks");
				double totalCost = rs.getDouble("TotalCost");

				
				PortfolioItem pi = new PortfolioItem(ticker, totalCost, numStocks, userID);
				
				trades.add(pi);
			}
			
			rs.close();
			
			/*if (rs.next()) {
				double balance = Double.parseDouble(rs.getString("Balance"));

				if (balance >= t.getCost()) {
					rs.close();
					verify1 = st.executeUpdate("UPDATE Users SET Balance = " + (balance - t.getCost()) + " WHERE UserID=" + t.getUserID() + "");
					verify2 = st.executeUpdate("INSERT INTO Portfolio (UserID, Ticker, NumStock, Price) VALUES(" + t.getUserID() + ", '" + t.getTicker() + "', " + t.getNumStock() + ", " + t.getPrice() +")");
					if ((verify1 == 1) && (verify2 == 1)) { 
						result = 1;
					}
					
				}
			
			}*/
		}
		
		catch (SQLException sqle) {
			System.out.println("SQLException is in loadPortfolio");
			sqle.printStackTrace();
		}
		
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (st != null) {
					st.close();
				}
				
				if (conn != null) {
					conn.close();
				}
			}
			
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		//return result;
		return trades;
			
	}
	
	
	public static double getBalance(int userID) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		}
		
		catch (ClassNotFoundException e) {
			e.printStackTrace();
			
		}
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		double balance = 0;
		
		
		/*int verify1 = 0;
		int verify2 = 0;*/
		
		try {
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/assignment4?user=root&password=Banari69");
			st = conn.createStatement();
			rs = st.executeQuery("SELECT Balance FROM Users WHERE UserID=" + userID + "");
			rs.next();
			
			//if (rs.next()) {
			balance = rs.getDouble("Balance");
			
			rs.close();
			
			/*if (rs.next()) {
				double balance = Double.parseDouble(rs.getString("Balance"));

				if (balance >= t.getCost()) {
					rs.close();
					verify1 = st.executeUpdate("UPDATE Users SET Balance = " + (balance - t.getCost()) + " WHERE UserID=" + t.getUserID() + "");
					verify2 = st.executeUpdate("INSERT INTO Portfolio (UserID, Ticker, NumStock, Price) VALUES(" + t.getUserID() + ", '" + t.getTicker() + "', " + t.getNumStock() + ", " + t.getPrice() +")");
					if ((verify1 == 1) && (verify2 == 1)) { 
						result = 1;
					}
					
				}
			
			}*/
		}
		
		catch (SQLException sqle) {
			System.out.println("SQLException is in getBalance");
			sqle.printStackTrace();
		}
		
		finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (st != null) {
					st.close();
				}
				
				if (conn != null) {
					conn.close();
				}
			}
			
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		//return result;
		return balance;
			
	}


	
	
	public static void main(String[] args) {
			
	}

}
