package paripand_CSCI201L_Assignment1;
import java.util.ArrayList;

public class Data {
	
	Data() {
		
	}
	
	Data(ArrayList<Stock> stocks) {
		data = stocks;
	}
	
	ArrayList<Stock> data;
	public ArrayList<Stock> getData() {
		
		return data;
	}

}
