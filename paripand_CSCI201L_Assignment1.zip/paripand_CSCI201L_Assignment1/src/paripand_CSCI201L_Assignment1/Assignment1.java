package paripand_CSCI201L_Assignment1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import org.apache.commons.text.WordUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;


public class Assignment1 {
	
	public static boolean validDate(String date) {
		
		return date.matches("\\d{4}-\\d{2}-\\d{2}");
		
	}
	
	public static boolean validExchange(String exchange) {
		
		return (exchange.equalsIgnoreCase("NASDAQ") || exchange.equalsIgnoreCase("NYSE"));
		
	}

	public static void main(String[] args) {
		FileReader fr;
		Scanner in = new Scanner(System.in);		
		int instruction = 0;
		String name = "";
		boolean validFile = false;
		boolean isDone = false;
		boolean errors = false;
		Gson gson = null;
		Data data = null;
		ArrayList<Stock> stocks = null;
			
		while (!validFile) {
			
			
			try {
				System.out.print("What is the name of the company file? ");

				name = in.next();
				fr = new FileReader(name);
				gson = new Gson();
				data = gson.fromJson(fr, Data.class);
				isDone = false;
				errors = false;
				stocks = data.getData();
				
				for (int i = 0; i < stocks.size(); i++) {
					
					if (stocks.get(i).missingParameters()) {
						System.out.println("The file " + name + " is missing data parameters.\n");
						errors = true;
						break;
					}
					
					if (!validDate(stocks.get(i).getStartDate())) {
						System.out.println("A start date in " + name + " is not in the YYYY-MM-DD format.\n");
						errors = true;
						break;
					}
					
					if (!validExchange(stocks.get(i).getExchangeCode())) {
						System.out.println("A stock in " + name + " is not on the NASDAQ or the NYSE.\n");
						errors = true;
						break;
					}
				}
				
				
				if (!errors) {
					System.out.println("The file has been properly read.\n");
					validFile = true;
				}
			}
			
			catch (FileNotFoundException fnfe) {
				System.out.println("The file " + name + " could not be found.\n");
			}
			
			catch (NullPointerException ne) {
				System.out.println("The file " + name + " is empty.\n");
			}
			
			catch (JsonSyntaxException jse) {
				System.out.println("The file " + name + " is not formatted properly.\n");
			}
			
			catch (JsonParseException jpe) {
				System.out.println("The file " + name + " is not formatted properly.\n");
			}

		}
		
		
		while (!isDone) {
			
			try {
				
				if (!errors) {
					System.out.print("\t1) Display all public companies\n\t2) Search for a stock\n\t3) Search for all stocks on an exchange\n\t4) Add a new company/stocks\n\t5) Remove a company\n\t6) Sort companies\n\t7) Exit\n");
				}
				
				System.out.print("What would you like to do? ");
				instruction = in.nextInt();
				in.nextLine();
				System.out.println();
				errors = false;
				
				if (instruction == 1) {
					
					
					for (int i = 0; i < stocks.size(); i++) {
						stocks.get(i).identify();
						System.out.println(",\n\t" + WordUtils.wrap(stocks.get(i).getDescription(), 100));
					}
					
					System.out.println();
					
				}
				
				else if (instruction == 2) {
					boolean found = false;
					
					while (!found)  {
						
						System.out.print("What is the ticker of the company you would like to search for? ");
						String ticker = in.next();
						System.out.println();
						for (int i = 0; i < stocks.size() && !found; i++) {
							if (stocks.get(i).getTicker().equalsIgnoreCase(ticker)) {
								stocks.get(i).identify();
								System.out.println();
								found = true;
							}
						}
						
						if (!found) {
							System.out.println(ticker + " could not be found.");
						}
						
						System.out.println();
					}
					
				}
				
				else if (instruction == 3) {
					boolean done = false;
					String stockExchange = "";
					
					while (!done) {
					
					
						System.out.print("What Stock Exchange would you like to search for? ");
						stockExchange = in.next();
						System.out.println();
					
						if (!validExchange(stockExchange)) {
							System.out.println("No exchange named " + stockExchange + " found.\n");	
						}
						
						else {
							done = true;
						}
					
					}
					
						
					ArrayList<String> tickers = new ArrayList<String>();
					
					for (int i = 0; i < stocks.size(); i++) {
						if (stocks.get(i).getExchangeCode().equalsIgnoreCase(stockExchange)) {
							tickers.add(stocks.get(i).getTicker());
						}
					}
					
					for (int i = 0; i < tickers.size(); i++) {
						
						if (i != tickers.size() - 1) {
							System.out.print(tickers.get(i) + ", ");
						}
						
						else {
							if (i != 0) {
								
								System.out.print("and ");
							}
							
							System.out.println(tickers.get(i) + " found on the " + stockExchange.toUpperCase() + " exchange.\n");
						}
						
					}
					
					if (tickers.size() == 0) {
						
						System.out.println("No companies found on the " + stockExchange.toUpperCase() + ".\n");
					}
					
								
				}
	
				else if (instruction == 4) {
					boolean done = false;
					boolean found = false;
					String companyName = "";
					
					while (!done) {
						
						System.out.print("What is the name of the company you would like to add? ");
						companyName = in.nextLine();
						System.out.println();
						
						for (int i = 0; i < stocks.size() && !found; i++) {
							if (stocks.get(i).getName().equalsIgnoreCase(companyName)) {
								System.out.println("There is already an entry for " + stocks.get(i).getName() + ".\n");
								found = true;
							}
						}
						
						if (!found) {
							done = true;
						}
						
						else {
							found = false;
						}
					}
					
					
					Stock newStock = new Stock();
					newStock.setName(companyName);
					

					done = false;
					String ticker = "";
					
					while (!done) {
						System.out.print("What is the stock symbol of " + companyName + "? ");
						ticker = in.next();
						System.out.println();
						
						for (int i = 0; i < stocks.size() && !found; i++) {
							if (stocks.get(i).getTicker().equalsIgnoreCase(ticker)) {
								System.out.println("There is already an entry for " + stocks.get(i).getTicker() + ".\n");
								found = true;
							}
						}
						
						if (!found) {
							done = true;
						}
						
						else {
							found = false;
						}
					}
					
					newStock.setTicker(ticker);
					
					done = false;
					String startDate = "";
					
					while (!done) {
						System.out.print("What is the start date of " + companyName + "? ");
						startDate = in.next();
						System.out.println();
						if (validDate(startDate)) {
							done = true;
							break;
						}
						
						else {
							System.out.println("That is not a valid date.\n");
							
						}
					}
					
					newStock.setStartDate(startDate);
					
					done = false;
					String stockExchange = "";
					
					while (!done) {
						System.out.print("What is the exchange where " + companyName + " is listed? ");
						stockExchange = in.next();
						System.out.println();
						if (validExchange(stockExchange)) {
							done = true;
							break;
						}
						
						else {
							System.out.println("That is not a valid stock exchange (NASDAQ or NYSE).\n");
							
						}
					}
					
					newStock.setExchangeCode(stockExchange);
					
					System.out.print("What is the description of " + companyName + "? ");
					in.nextLine();
					String desc = in.nextLine();
					while (desc.length() == 0) {
						desc = in.nextLine();
					}
					newStock.setDescription(desc);
					System.out.println();
					
					System.out.println("There is now a new entry for:");
					newStock.identify();
					System.out.println(",\n\t" + WordUtils.wrap(newStock.getDescription(), 100));
					stocks.add(newStock);
					System.out.println();
					
				}
	
				else if (instruction == 5) {
					
					for (int i = 0; i < stocks.size(); i++) {
						System.out.print("\t" + (i+1) + ") " + stocks.get(i).getName()+"\n");
					}
					System.out.print("Which company would you like to remove? ");
					
					int number = in.nextInt();
					System.out.println();
					
					
					if (number < 1 || number > stocks.size()) {
						
						System.out.println("Sorry, that company doesn't exist.\n");
					}
					
					else {
						System.out.println(stocks.get(number-1).getName() + " is now removed.\n");
						stocks.remove(number - 1);
					}
					
				}
	
				else if (instruction == 6) {
					// sorting
					
					System.out.println("\t1) A to Z\n\t2) Z to A\n");
					System.out.print("How would you like to sort by? ");
					int response = in.nextInt();
					System.out.println();
					
					Comparator<Stock> comparator = Comparator.comparing(Stock::getNameIgnoreCase);
					
					if (response == 1) {
						System.out.println("Your companies are now sorted in alphabetical order (A-Z).\n");
					}

					else if (response == 2) {
				        // Reverse the order if Z to A is selected
				    	comparator = comparator.reversed();
				    	System.out.println("Your companies are now sorted in reverse alphabetical order (Z-A).\n");
				    }

				    Collections.sort(stocks, comparator);
				    
					
				}
	
				else if (instruction == 7) {
					
					System.out.println("\t1) Yes\n\t2) No");
					System.out.print("Would you like to save your edits? ");
					int response = in.nextInt();
					System.out.println();
		
					if (response == 1) {
						FileWriter fw = new FileWriter(name);
						PrintWriter pw = new PrintWriter(fw);
						data = new Data(stocks);
						Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
						String result = gson2.toJson(data);
						pw.print(result);

						System.out.println("Your edits have been saved to "  + name);
						pw.close();
					}
					
					System.out.println("Thank you for using my program!");
					isDone = true;
				}
				
				else {
					
					System.out.println("That is not a valid option.\n");
					errors = true;
				}
				
			}
			
			catch (InputMismatchException io) {
				System.out.println();
				System.out.println("That is not a valid option.\n");
				in.nextLine();
				errors = true;
				
			}
				
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		in.close();
				
	}
}
