package paripand_CSCI201L_Assignment1;

public class Stock {
	
	private String name;
    private String ticker;
    private String startDate;
    private String description;
    private String exchangeCode;
    
    Stock() {
    	
    }
    

    //getters and setters
    
    void setName(String name_) {
    	name = name_;
    }
    
    void setTicker(String ticker_) {
    	ticker = ticker_;
    }
    
    void setStartDate(String startDate_) {
    	startDate = startDate_;
    }
    
    void setDescription(String description_) {
    	description = description_;
    }
    
    void setExchangeCode(String exchangeCode_) {
    	exchangeCode = exchangeCode_;
    }
    
    public String getName() {
    	return name;
    }
    
    public String getNameIgnoreCase() {
    	return name.toLowerCase();
    }
    
    public String getTicker() {
    	return ticker;
    }
    
    public String getStartDate() {
    	return startDate;
    }
    
    public String getDescription() {
    	return description;
    }
    
    public String getExchangeCode() {
    	return exchangeCode;
    }
    
    void identify() {
    	
    	System.out.print(name + ", symbol " + ticker + ", started on " + startDate + ", listed on " + exchangeCode);
  
    }
    
    boolean missingParameters() {
    	return (name == null || ticker == null || startDate == null || description == null || exchangeCode == null || name.isEmpty() || ticker.isEmpty() || description.isEmpty());
    }
    


}
