package paripand_CSCI201L_Assignment2;

import com.google.gson.Gson;

import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.io.FileNotFoundException;



public class Assignment2 {
	
	public static boolean validDate(String date) {
		
		return date.matches("\\d{4}-\\d{2}-\\d{2}");
		
	}
	
	public static boolean validExchange(String exchange) {
		
		return (exchange.equalsIgnoreCase("NASDAQ") || exchange.equalsIgnoreCase("NYSE"));
		
	}
	
	public static void main(String[] args) {
		FileReader fr;
		Scanner in = new Scanner(System.in);		
		String name = "";
		boolean validFile = false;
		boolean errors = false;
		Gson gson = null;
		Data data = null;
		ArrayList<Stock> stocks = null;
		ArrayList<String> stockNames = new ArrayList<String>();
		ArrayList<Transaction> csv_items = null;
		ArrayList<Semaphore> sems = new ArrayList<Semaphore>();
			
		while (!validFile) {
			
			
			try {
				System.out.println("What is the name of the file containing the company information?");

				name = in.next();
				fr = new FileReader(name);
				gson = new Gson();
				data = gson.fromJson(fr, Data.class);
				errors = false;
				stocks = data.getData();

				for (int i = 0; i < stocks.size(); i++) {
					
					
					if (stocks.get(i).missingParameters()) {
						System.out.println("The file " + name + " is missing data parameters.\n");
						errors = true;
						break;
					}
					
					if (!validDate(stocks.get(i).getStartDate())) {
						System.out.println("A start date in " + name + " is not in the YYYY-MM-DD format.\n");
						errors = true;
						break;
					}
					
					if (!validExchange(stocks.get(i).getExchangeCode())) {
						System.out.println("A stock in " + name + " is not on the NASDAQ or the NYSE.\n");
						errors = true;
						break;
					}
					

					
					stockNames.add(stocks.get(i).getTicker().toUpperCase());
					sems.add(new Semaphore(stocks.get(i).getStockBrokers(), true));

				}
				
				
				if (!errors) {
					System.out.println("The company file has been properly read.\n");
					validFile = true;
				}
				
				else {
					return;
				}
			}
			
			catch (FileNotFoundException fnfe) {
				System.out.println("The file " + name + " could not be found.\n");
				return;
			}
			
			catch (NullPointerException ne) {
				System.out.println("The file " + name + " is empty.\n");
				return;
			}
			
			catch (JsonSyntaxException jse) {
				System.out.println("The file " + name + " is not formatted properly.\n");
				return;
			}
			
			catch (JsonParseException jpe) {
				System.out.println("The file " + name + " is not formatted properly.\n");
				return;
			}
			

			
			try {
				System.out.println("\nWhat is the name of the file containing the schedule information?");

				name = in.next();
				
				Scanner sc = new Scanner(new FileReader(name));  
				
				//sc.useDelimiter(",");   //
				csv_items = new ArrayList<Transaction>();
		
		
				
				if (!sc.hasNext()) {
					System.out.println("The schedule file is empty.");
					validFile = false;
					return;
				}
				

				while (sc.hasNext()) {
					sc.useDelimiter(",");
					String seconds = sc.next().strip();
					
					if (Integer.parseInt(seconds) < 0) {
						System.out.println("A negative number of seconds is not valid.");
						validFile = false;
						errors = true;
						break;
					}
					
					
					String ticker = sc.next();
					
					if (!stockNames.contains(ticker.toUpperCase())) {
						System.out.println("That ticker (" + ticker + ") is not in the list.");
						validFile = false;
						errors = true;
						break;
					}
					
					String quantity = sc.next();
					sc.useDelimiter("\n");
					String four = sc.next().substring(1).strip();
					
					if (Integer.parseInt(four) < 0) {
						System.out.println("A negative cost is not possible.");
						errors = true;
						validFile = false;
						break;
					}
					
					
					csv_items.add(new Transaction(Integer.parseInt(seconds), ticker, Integer.parseInt(quantity), Integer.parseInt(four), sems.get(stockNames.indexOf(ticker.toUpperCase()))));
				}
				
				sc.close();  //closes the scanner  
				
				if (errors) {
					System.out.println("The schedule file is not formatted properly.");
					validFile = false;
					return;
				}
				
				else {
					System.out.println("The schedule file " + name + " has been properly read.\n");
					validFile = true;
					break;
				}

				
			}
			
	
		
		catch (FileNotFoundException fnfe) {
			System.out.println("The schedule file " + name + " could not be found.\n");
			validFile = false;
			return;
		}
		
		catch (NullPointerException ne) {
			System.out.println("The schedule file " + name + " is empty.\n");
			validFile = false;
			return;
		}
		
		
		catch (NumberFormatException nfe) {
			System.out.println("The schedule file is not formatted properly.");
			validFile = false;
			return;
			
		}
			
		
	}
		
		if (validFile) {
			int balance = -1;
			Comparator<Transaction> comparator = Comparator.comparing(Transaction::getSecondsAfter);

		    
		    try {
				while (balance < 0) {
					System.out.println("What is the initial balance?");
					balance = in.nextInt();
				}
		    }
		    
		    catch (InputMismatchException ime) {
		    	System.out.println("That is not a valid integer/balance.");
		    	in.close();
		    	return;
		    }
		    
		    in.close();
		    
		    Collections.sort(csv_items, comparator);
		    
	
			System.out.println();
			System.out.println("Starting execution of program...");
			
			System.out.println();
			System.out.println("Initial Balance: " + balance);
			Transaction.setBalance(balance);
			
			ExecutorService executors = Executors.newCachedThreadPool();
		
			

	        for (int i = 0; i < csv_items.size(); i++) {
	            executors.execute(csv_items.get(i));
	        }
	        
			executors.shutdown();
			
			
			while (!executors.isTerminated()) {
				Thread.yield();
		
			}
			
			System.out.println("All trades completed!");
			
		
		}
		
				
	}
}

