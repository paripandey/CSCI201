package paripand_CSCI201L_Assignment2;
import java.util.ArrayList;

public class Data {
	
	Data() {
		
	}
	
	
	ArrayList<Stock> data;
	
	
	public ArrayList<Stock> getData() {
		
		return data;
	}

}
