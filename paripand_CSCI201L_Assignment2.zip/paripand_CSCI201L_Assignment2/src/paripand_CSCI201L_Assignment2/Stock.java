package paripand_CSCI201L_Assignment2;

public class Stock {
	
	private String name;
    private String ticker;
    private String startDate;
    private int stockBrokers = -1;
    private String description;
    private String exchangeCode;

    
    Stock() {
    	
    }
    

    //getters and setters
   
    
    public String getTicker() {
    	return ticker;
    }
    
    public String getStartDate() {
    	return startDate;
    }
    
    public int getStockBrokers() {
    	return stockBrokers;
    }
    

    public String getExchangeCode() {
    	return exchangeCode;
    }
    
    
    boolean missingParameters() {
    	return (name == null || ticker == null || startDate == null || description == null || exchangeCode == null || name.isEmpty() || ticker.isEmpty() || description.isEmpty());
    }
    


}
