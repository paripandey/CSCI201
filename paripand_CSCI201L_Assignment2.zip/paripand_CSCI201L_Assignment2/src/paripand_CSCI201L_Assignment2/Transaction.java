package paripand_CSCI201L_Assignment2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Transaction extends Thread {
	
	private int secondsAfter;
	private String ticker;
	private int quantity;
	private int cost;
	private Semaphore sem;
	private static int balance;
	private static Lock lock = new ReentrantLock();
	private static DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
	private static Calendar startTime;

	
	
	Transaction(int secondsAfter, String ticker, int quantity, int cost, Semaphore sem) {
		this.secondsAfter = secondsAfter;
		this.ticker = ticker;
		this.quantity = quantity;
		this.cost = cost;
		this.sem = sem;
	}
	
 //getters and setters

    public int getSecondsAfter() {
    	return secondsAfter;
    }
    
    
    public static void setBalance(int balance_) {
    	balance = balance_;
    }
    
    public static void setStartTime() {
    	startTime = Calendar.getInstance();
    }
    
  
 	
    public void run() {
    	 

    	setStartTime();
    	
    	try {
    		Thread.sleep(secondsAfter * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	try {
			sem.acquire();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
    	
    	Calendar currentTime = Calendar.getInstance();
		Calendar adjustedStartTime = Calendar.getInstance();
		adjustedStartTime.set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY) - startTime.get(Calendar.HOUR_OF_DAY));
		adjustedStartTime.set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE) - startTime.get(Calendar.MINUTE));
		adjustedStartTime.set(Calendar.SECOND, currentTime.get(Calendar.SECOND) - startTime.get(Calendar.SECOND));
		adjustedStartTime.set(Calendar.MILLISECOND, currentTime.get(Calendar.MILLISECOND) - startTime.get(Calendar.MILLISECOND));
		String started = dateFormat.format(adjustedStartTime.getTime());
			
		
    
    	System.out.println("[" + started + "] Starting " + ((quantity > 0) ? "purchase of " + quantity: "sale of " + -quantity) + " stocks of " + ticker);
    	
    	if (quantity > 0) {
    		try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    	
    	else if (quantity < 0) {
    		try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    	
    
    	//synchronized(this) {
		lock.lock();
		
		if (balance - (quantity * cost) >= 0) {
			balance -= (quantity * cost);
			
			Calendar endTime = Calendar.getInstance();
			
			Calendar adjustedEndTime = Calendar.getInstance();
			adjustedEndTime.set(Calendar.HOUR_OF_DAY, endTime.get(Calendar.HOUR_OF_DAY) - startTime.get(Calendar.HOUR_OF_DAY));
			adjustedEndTime.set(Calendar.MINUTE, endTime.get(Calendar.MINUTE) - startTime.get(Calendar.MINUTE));
			adjustedEndTime.set(Calendar.SECOND, endTime.get(Calendar.SECOND) - startTime.get(Calendar.SECOND));
			adjustedEndTime.set(Calendar.MILLISECOND, endTime.get(Calendar.MILLISECOND) - startTime.get(Calendar.MILLISECOND));
			String finished = dateFormat.format(adjustedEndTime.getTime());
		
			System.out.println("[" + finished + "] Finished " + ((quantity > 0) ? "purchase of " + quantity: "sale of " + -quantity) + " stocks of " + ticker);
			System.out.println("Current Balance after trade: " + balance);
		}
		
		else {
			System.out.println("Transaction failed due to insufficient balance. Unsuccessful " + ((quantity > 0) ? "purchase of " + quantity: "sale of " + -quantity) + " stocks of " + ticker);
		}
		

		lock.unlock();
		sem.release();
    }

	
   	

}
