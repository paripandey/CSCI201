package paripand_CSCI201L_Assignment3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;

public class ServerThread extends Thread {
	private PrintWriter pw;
	private BufferedReader br;
	private Server s;
	
	private Trader trader;
	private int serialNumber;
	private double balance;
	private double original;
	private boolean available;
	private Vector<Transaction> assignedTrades;
	private Vector<Transaction> failedTrades;
	private static Calendar startTime;
	private static DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
	private double profit;
	
	public ServerThread(Socket s, Server s_, Trader trader, boolean available) {
		try {
			this.trader = trader;
			this.s = s_;
			this.available = available;
			profit = 0;
			assignedTrades = new Vector<Transaction>();
			serialNumber = trader.getSerialNumber();
			balance = trader.getBalance();
			original = balance;
			pw = new PrintWriter(s.getOutputStream());
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			this.start();
		}
		catch (IOException ioe) {
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}
	
	public void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
	
	public void setStatus(boolean status) {
		
		available = status;
	}
	
	public static void setStartTime() {
		
		startTime = Calendar.getInstance();
	}
	
	public boolean isFree() {
		
		return available;
	}
	
	public double getBalance() {
		
		return balance;
	}
	
	public void assignTrade(Transaction t) {
		
		

		try {
			Thread.sleep(t.getSecondsAfter() * 1000);
			String message = "Assigned " + (t.getQuantity() > 0 ? "purchase of " + Integer.toString(t.getQuantity()) : "sale of " + Integer.toString(-1 * t.getQuantity())) + " stock(s) of " + t.getTicker() + ". ";
			message += "Total " + (t.getQuantity() > 0 ? "gain estimate: " : "cost estimate: ") + t.getCost() + " * " + Math.abs(t.getQuantity()) + " = " + Math.abs(t.getCost() * t.getQuantity()) + ".";
			
			
			Calendar currentTime = Calendar.getInstance();
			Calendar adjustedStartTime = Calendar.getInstance();
			adjustedStartTime.set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY) - startTime.get(Calendar.HOUR_OF_DAY));
			adjustedStartTime.set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE) - startTime.get(Calendar.MINUTE));
			adjustedStartTime.set(Calendar.SECOND, currentTime.get(Calendar.SECOND) - startTime.get(Calendar.SECOND));
			adjustedStartTime.set(Calendar.MILLISECOND, currentTime.get(Calendar.MILLISECOND) - startTime.get(Calendar.MILLISECOND));
			String started = dateFormat.format(adjustedStartTime.getTime());
			
			
			sendMessage("[" + started + "] " + message);
			assignedTrades.add(t);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void runAllTrades() {
		
		
		//synchronized(this) {
			available = false;
			for (Transaction t : assignedTrades) {
			
			
				if (balance - t.getEstimatedCost() >= 0) {
					try {
						String message = "Starting " + (t.getQuantity() > 0 ? "purchase of " + Integer.toString(t.getQuantity()) : "sale of " + Integer.toString(-1 * t.getQuantity())) + " stock(s) of " + t.getTicker() + ". ";
						//Thread.sleep(t.getSecondsAfter() * 1000);
						message += " Total " + (t.getQuantity() > 0 ? "gain: " : "cost: ") + t.getCost() + " * " + Math.abs(t.getQuantity()) + " = " + Math.abs(t.getCost() * t.getQuantity()) + ".";
						Calendar currentTime = Calendar.getInstance();
						Calendar adjustedStartTime = Calendar.getInstance();
						adjustedStartTime.set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY) - startTime.get(Calendar.HOUR_OF_DAY));
						adjustedStartTime.set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE) - startTime.get(Calendar.MINUTE));
						adjustedStartTime.set(Calendar.SECOND, currentTime.get(Calendar.SECOND) - startTime.get(Calendar.SECOND));
						adjustedStartTime.set(Calendar.MILLISECOND, currentTime.get(Calendar.MILLISECOND) - startTime.get(Calendar.MILLISECOND));
						String started = dateFormat.format(adjustedStartTime.getTime());
						
						sendMessage("[" + started + "] " + message);
						
						Thread.sleep(1000);
						message = "Finishing " + (t.getQuantity() > 0 ? "purchase of " + Integer.toString(t.getQuantity()) : "sale of " + Integer.toString(-1 * t.getQuantity())) + " stock(s) of " + t.getTicker() + ".";
						currentTime = Calendar.getInstance();
						adjustedStartTime = Calendar.getInstance();
						adjustedStartTime.set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY) - startTime.get(Calendar.HOUR_OF_DAY));
						adjustedStartTime.set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE) - startTime.get(Calendar.MINUTE));
						adjustedStartTime.set(Calendar.SECOND, currentTime.get(Calendar.SECOND) - startTime.get(Calendar.SECOND));
						adjustedStartTime.set(Calendar.MILLISECOND, currentTime.get(Calendar.MILLISECOND) - startTime.get(Calendar.MILLISECOND));
						started = dateFormat.format(adjustedStartTime.getTime());
						
						sendMessage("[" + started + "] " + message);
						balance -= t.getEstimatedCost();
						//assignedTrades.remove(t);
						
					}
					
					catch (InterruptedException e) {
					// TODO Auto-generated catch block
						e.printStackTrace();
					}		
						
				}
				
				if (t.getQuantity() < 0) {
					
					profit += t.getQuantity() * t.getCost() * -1;
					
				}
				
			}
			
		assignedTrades = new Vector<Transaction>();
		available = true;
		//}

		
		
	}
	
	public double getProfit() {
		
		return profit;
	}
	
	public double getCost() {
		
		return (original - balance);
	}
	
	

	public void run() {
		try {
			while(true) {
				String line = br.readLine();
				s.broadcast(line, this);
			}
		} 
		catch (IOException ioe) {
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
	 	}
	}
	
}
