package paripand_CSCI201L_Assignment3;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Transaction {
	
	private int secondsAfter;
	private String ticker;
	private int quantity;
	private double cost;
	private Semaphore sem;
	private static int balance;
	private static Lock lock = new ReentrantLock();
	private static DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss.SSS");
	private static Calendar startTime;

	
	
	Transaction(int secondsAfter, String ticker, double cost, int quantity) {
		this.secondsAfter = secondsAfter;
		this.ticker = ticker;
		this.quantity = quantity;
		this.cost = cost;
	}
	
	Transaction(int secondsAfter, String ticker, int quantity) {
		this.secondsAfter = secondsAfter;
		this.ticker = ticker;
		this.quantity = quantity;
	}
	
 //getters and setters

    public int getSecondsAfter() {
    	return secondsAfter;
    }
    
    public int getQuantity() {
    	return quantity;
    }
    
    public double getCost() {
    	return cost;
    }
    
    public String getTicker() {
    	return ticker;
    }
    
    
    public double getEstimatedCost() {
    	if (quantity > 0) {
    		
    		return quantity * cost;
    	}
    	
    	else {
    		
    		return 0;
    	}
    }
    
    
    
    public static void setBalance(int balance_) {
    	balance = balance_;
    }
    
    public static void setStartTime() {
    	
    }
    
  
 	
   	

}
