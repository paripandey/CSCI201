package paripand_CSCI201L_Assignment3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Scanner;
import java.util.Vector;
import java.util.LinkedList;

import com.google.gson.Gson;
	 
	public class Server {

	
	 private Vector<ServerThread> serverThreads;
	 LinkedList<Transaction> csv_items;
	 LinkedList<Transaction> copy_csv;
	 ArrayList<Trader> traders;
	 private static DateFormat dateFormat = new SimpleDateFormat("mm/dd/YYYY HH:mm:ss.SSS");
	 
	 
	 
	 
	 private int numTraders = 0;
	 
	 public Server(int port) {
		 try {
			 //System.out.println("Binding to port " + port);
			 System.out.println();
			 ServerSocket ss = new ServerSocket(port);
			 //System.out.println("Bound to port " + port);
			 serverThreads = new Vector<ServerThread>();
			 
			 if (parseFiles()) {
				 System.out.println("Listening on port " + port);
				 System.out.println("Waiting for traders...");

			 
				 while(true) {
					 Socket s = ss.accept(); // blocking
					 System.out.println("Connection from: " + s.getInetAddress());
					 ServerThread st = new ServerThread (s, this, traders.get(serverThreads.size()), true);
					 serverThreads.add(st);
					 
					 if (serverThreads.size() < numTraders) {
						 System.out.println("Waiting for " + (numTraders - serverThreads.size()) + " trader(s)...");
						 st.sendMessage((numTraders - serverThreads.size()) + " more trader(s) is needed before the service can begin.");
						 st.sendMessage("Waiting...");
					 }
					 
					 
					 else {
						 
						 for(ServerThread threads : serverThreads) {
							threads.sendMessage("All traders have arrived!");
							threads.sendMessage("Starting service.");
						 }
						 
						 break;
					 }
				 }
				 
				 System.out.println("Starting service.");
				 System.out.println("Processing complete.");
				 
				 run();
				  
			 }
			 
			 else {
				 ss.close();
			 }
			 
			 
		 }
		 
		 catch (IOException ioe) {
			 System.out.println("ioe in Server constructor: " + ioe.getMessage());
		 }
	}
	 
	 public void run() {
		 
		// for (ServerThread st : serverThreads) {
			 ServerThread.setStartTime();
		 //}
		 
		 while (csv_items.size() > 0) {
			 
			 for (int i = 0; i < serverThreads.size(); i++) {
				 
				 ServerThread st = serverThreads.get(i);
				 
				 if (st.isFree()) {
					 
					 Transaction t = csv_items.poll();
					 
					 if (st.getBalance() - t.getEstimatedCost() >= 0) {
						 st.assignTrade(t);
						 break;
					 }
					 
					 
					 else {
						 //st.setStatus(false);
						 st.runAllTrades();
						 continue;
					 }
					 
				 }
				 
			 }

		 }
		 
		 for (int i = 0; i < csv_items.size(); i++) {
			 Transaction t = csv_items.get(i);
			 boolean failedTrade = false;
			 for (ServerThread st : serverThreads) {
				 if (st.getBalance() < t.getEstimatedCost()) {
					 failedTrade  = true;
					 break;
				 }
			 }
			 
			 if (failedTrade) {
				 
				 String message = "Incomplete Trade: " + Integer.toString(t.getSecondsAfter()) + ", " + t.getTicker() + ", " + Integer.toString(t.getQuantity()) + " " + dateFormat.format(Calendar.getInstance().getTime());
				 broadcast(message, null);

			 }
			 
			 
		 }
		 
		 for (ServerThread st : serverThreads) {
			 st.sendMessage("Total Profit Earned from Sales: $" + st.getProfit() + ".");
			 st.sendMessage("Total Cost from Purchases: $" + st.getCost() + ".");
		 }

		 	 
	 }
	 
	 
	 
	 
	 // communicates between serverThreads (except itself)s
	 public void broadcast(String message, ServerThread st) {
		if (message != null) {
			System.out.println(message);
			for(ServerThread threads : serverThreads) {
				if (st != threads) {
					threads.sendMessage(message);
				}
			}
		}
	 }
	
	 public boolean parseFiles() {
		
		Gson gson = new Gson();
		Scanner in = new Scanner(System.in);
		String scheduleFile = "";
		String tradersFile = "";
		boolean validFile = false;
		boolean errors = false;
		Scanner sc = null;
		String apiKey = "cnus6shr01qub9j00tqgcnus6shr01qub9j00tr0";
		
		while (!validFile) {
		
			try {
				System.out.println("What is the name of the schedule file?");

				scheduleFile = in.next();
				
				sc = new Scanner(new FileReader(scheduleFile));  
				
				//sc.useDelimiter(",");   //
				csv_items = new LinkedList<Transaction>();
		
				
				if (!sc.hasNext()) {
					System.out.println("The schedule file is empty.");
					//validFile = false;
					return false;
				}
				

				while (sc.hasNext()) {
					sc.useDelimiter(",");
					String seconds = sc.next().strip();
					
					if (Integer.parseInt(seconds) < 0) {
						System.out.println("A negative number of seconds is not valid.");
						//validFile = false;
						errors = true;
						break;
					}
					
					
					String ticker = sc.next();
		
					URL ticker_ = new URL("https://finnhub.io/api/v1/quote?symbol="+ticker.toUpperCase()+"&token="+apiKey);
					
					InputStreamReader reader = new InputStreamReader(ticker_.openStream());
					Stock stock = gson.fromJson(reader, Stock.class);
					if (stock.getPrice() == 0.0) {
						System.out.println("That stock does not exist.");
						//validFile = false;
						errors = true;
						break;
					}
					
					sc.useDelimiter("\n");
					String quantity = sc.next().substring(1).strip();
					
					
					csv_items.add(new Transaction(Integer.parseInt(seconds), ticker, stock.getPrice(), Integer.parseInt(quantity)));
				
				}
				
				
				if (errors) {
					System.out.println("The schedule file is not formatted properly.");
					//validFile = false;
					return false;
				}
				
				System.out.println("The schedule file " + scheduleFile + " has been properly read.\n");
			}
			

			catch (FileNotFoundException fnfe) {
				System.out.println("The schedule file " + scheduleFile + " could not be found.\n");
				//validFile = false;
				return false;
			}
			
			catch (NullPointerException ne) {
				System.out.println("The schedule file " + scheduleFile + " is empty.\n");
				//validFile = false;
				return false;
			}
			
			
			catch (NumberFormatException nfe) {
				System.out.println("The schedule file is not formatted properly.");
				//validFile = false;
				return false;
				
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				
				
				System.out.println("What is the name of the traders file?");
				
				tradersFile = in.next();
				
				sc = new Scanner(new FileReader(tradersFile));  
				
				//sc.useDelimiter(",");   //
				traders = new ArrayList<Trader>();
		
				
				if (!sc.hasNext()) {
					System.out.println("The traders file is empty.");
					//validFile = false;
					return false;
				}
				

				while (sc.hasNext()) {
					sc.useDelimiter(",");
					String serialNumber = sc.next().strip();
					
					if (Integer.parseInt(serialNumber) < 0) {
						System.out.println("A negative serial number is not valid.");
						//validFile = false;
						errors = true;
						break;
					}
					
					sc.useDelimiter("\n");
					String initialBalance = sc.next().substring(1).strip();
					
					if (Integer.parseInt(initialBalance) < 0) {
						System.out.println("A negative balance is not possible.");
						errors = true;
						//validFile = false;
						break;
					}
					
					traders.add(new Trader(Integer.parseInt(serialNumber), Integer.parseInt(initialBalance)));
				}
				
				Comparator<Trader> c = Comparator.comparing(Trader::getSerialNumber);
				traders.sort(c);
				

				sc.close();  //closes the scanner
				
				numTraders = traders.size();
				
				if (errors) {
					System.out.println("The traders file is not formatted properly.");
					//validFile = false;
					return false;
				}
				
				else {
					System.out.println("The traders file " + tradersFile + " has been properly read.\n");
					validFile = true;
					break;
				}
				
			}
		
			catch (FileNotFoundException fnfe) {
				System.out.println("The traders file " + tradersFile + " could not be found.\n");
				//validFile = false;
				return false;
			}
			
			catch (NullPointerException ne) {
				System.out.println("The traders file " + tradersFile + " is empty.\n");
				//validFile = false;
				return false;
			}
			
			
			catch (NumberFormatException nfe) {
				System.out.println("The traders file is not formatted properly.");
				//validFile = false;
				return false;
				
			}
			
		}
		
	
		in.close();
		
		
		
		return true;
				
	}
	
	
	public static void main(String[] args) {
		Server serverSocket = new Server(3456);
	}
	
}
