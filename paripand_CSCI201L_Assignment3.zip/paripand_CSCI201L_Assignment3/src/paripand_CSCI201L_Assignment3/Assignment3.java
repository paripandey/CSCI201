package paripand_CSCI201L_Assignment3;
import com.google.gson.Gson;

import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.io.FileNotFoundException;

public class Assignment3 {
	
	
	public static boolean validDate(String date) {
		
		return date.matches("\\d{4}-\\d{2}-\\d{2}");
		
	}
	
	public static boolean validExchange(String exchange) {
		
		return (exchange.equalsIgnoreCase("NASDAQ") || exchange.equalsIgnoreCase("NYSE"));
		
	}
	
	
	
	public static void main(String[] args) {
		
		
	}
}


