package paripand_CSCI201L_Assignment3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client extends Thread {

	private BufferedReader br;
	private PrintWriter pw;
	private String hostname;
	private int port;
	
	public Client() {
		try {
			// System.out.println("Trying to connect to " + hostname + ":" + port);
			Scanner in = new Scanner(System.in);
			System.out.println("Welcome to JoesStocks v2.0!");
			System.out.println("Enter the server hostname:");
			hostname = in.next();
			System.out.println("Enter the server port:");
			port = in.nextInt();
			
			
			/*1 more trader is needed before the service can begin.
			Waiting...
			All traders have arrived!
			Starting service.
			[00:00:00.006] As*/
			
			
			Socket s = new Socket(hostname, port);
			System.out.println("Connected to " + hostname + ":" + port);
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			pw = new PrintWriter(s.getOutputStream());
			this.start();
			Scanner scan = new Scanner(System.in);
			while(true) {
				String line = scan.nextLine();
				pw.println("Donald: " + line);
				pw.flush();
			}
		}
		
		catch (IOException ioe) {
			System.out.println("ioe in Client constructor: " + ioe.getMessage());
		}
		
	}
	
	public void run() {
		try {
			while(true) {
				String line = br.readLine();
				System.out.println(line);
			}
		}
		
		catch (IOException ioe) {
		System.out.println("ioe in Client.run(): " + ioe.getMessage());
		}
	} 
	



	public static void main(String [] args) {
		Client client1 = new Client();
		//Client client2 = new Client("localhost", 3456);
		
	}
}
