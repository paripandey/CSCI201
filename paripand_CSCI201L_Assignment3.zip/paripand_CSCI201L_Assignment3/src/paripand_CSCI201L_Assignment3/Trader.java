package paripand_CSCI201L_Assignment3;

public class Trader extends Thread {
	private int serialNumber;
	private int balance;
	
	Trader(int serialNumber, int balance) {
		
		this.serialNumber = serialNumber;
		this.balance = balance;
		
	}
	
	public int getSerialNumber() {
		return serialNumber;
	}
	
	public int getBalance() {
		return balance;
	}
	
}
