package paripand_CSCI201L_Assignment3;

public class Stock {
	
	private double c;
   
    Stock() {
    	
    }
    
    public double getPrice() {
    	
    	return c;
    }

}
